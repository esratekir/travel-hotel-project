@extends('frontend.main_master')
@section('main')

<!-- Header Start -->
<div class="container-fluid page-header mobile-gizle">
  <div class="container">
    <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 250px;">
      <!-- <h3 class="display-4 text-white text-uppercase">Contact</h3>
      <div class="d-inline-flex text-white">
        <p class="m-0 text-uppercase"><a class="text-white" href="">Home</a></p>
        <i class="fa fa-angle-double-right pt-1 px-3"></i>
        <p class="m-0 text-uppercase">Contact</p>
      </div> -->
    </div>
  </div>
</div><!-- Header End -->

<div class="container-fluid py-5">
  <div class="container">
    <div class="row"> 
      <div class="col-md-3">
        <div class="margin-bottom-20"></div>
        <div class="sidebar margin-top-20">
          <div class="user-smt-account-menu-container">
            <ul class="user-account-nav-menu">
              <li><a href="#" ><i class="far fa-user"></i> Profil Bilgileri</a></li>
              <li><a href="#"><i class="fas fa-globe"></i> Ülke Seçimi</a></li>
              <li><a href="#"><i class="fas fa-language"></i> Dil Seçimi</a></li>
              <li><a href="#"><i class="fas fa-glass-cheers"></i> Aktivite Seçimi</a></li>
              <li><a href="#"><i class="fas fa-dollar-sign"></i> Fiyatlar</a></li>
              <li><a href="#"><i class="fas fa-image"></i> Fotoğraflar</a></li>
              <li><a href="#" class="current"><i class="fas fa-file-word"></i> Belgeler</a></li>
            </ul>            
          </div>
        </div>       
      </div>
      <div class="col-md-9">
        <div class="utf-user-profile-item">
          <div class="utf-submit-page-inner-box">
            <h3>Belgeler</h3>
            <div class="alert alert-success">{{ Session::get('message') }}</div>
              <div class="content with-padding">
                <form method="post" action="{{route('update.guide.register.step7')}}" id="contactForm" enctype="multipart/form-data">
                  @csrf
                  <input type="hidden" name="user_id" value="{{ $data->user_id }}">
                  <div class="control-group">
                    <label>Document:</label>
                    <input class="form-control" name="files" type="file" id="formFile">
                  </div>
                  <div class="control-group">
                    <ul class="pl-4 mt-3">
                      <li>PASAPORTunuzun veya benzeri bir belgenin fotoğrafını yükleyin.</li>
                      <li><strong>Neden gerekli?</strong> Ziyaretçilerimizin güvenliği için kiminle çalıştığımızı bilmemiz gerekiyor.</li>
                      <li><strong>Belgemi kimler görebilir?</strong> Sorunsuz ilerleyen turlarda belgeniz kimseyle paylaşılmayacaktır.</li>
                    </ul>
                  </div>
                  <div class="row">
                    <div class="col-md-12">
                      <button type="submit" class="btn btn-primary margin-top-0 margin-bottom-20">Register and Complete Your Registration</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>              
          </div>
        </div>          
      </div>
    </div>
  </div>
</div>

@endsection