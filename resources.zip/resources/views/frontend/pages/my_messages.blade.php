@extends('frontend.main_master')
@section('main')

@section('title')
Messages | TRAVELER
@endsection


<div class="container-fluid">
	<div class="container p-0 pt-5 pb-5 my-message-con">
		<main class="content conversation"> 	
			<div class=" mb-3 pb-3 pt-5">
      	<h1>Conversations</h1>
    	</div>
			@foreach($senders as $message)
			<div class="card">
				<div class="row g-0">
					<div class="col-lg-10">
						@foreach ($lastReceivedMessages as  $userId => $lastMessage)
							@if($userId==$message->user_id)
								@php
									$messageCount = $messageCountsBySender->firstWhere('sender_id', $message->user_id)->count ?? 0;
								@endphp
								<a href="{{ route('my.messages.details', $message->user_id) }}" class="list-group-item list-group-item-action border-0">
									@if($messageCount > 0)
										<div class="badge bg-success float-left">{{ $messageCount }}</div>
									@endif								
									<div class="d-flex align-items-center">										
										<img src="{{ asset($message->image) }}" class="rounded-circle mr-1" width="40" height="40">
										<div class="flex-grow-1 ml-2">{{ $message->name }}</div>
										<div class="flex-grow-1 ml-2">{{ $lastMessage->content}}</div>
									</div>	
								</a>
								<!-- <hr class="d-block  mt-1 mb-0"> -->
							@endif
						@endforeach			
					</div>
					<div class="col-lg-2 d-flex align-items-center"><a class="btn btn-sm" id="myButton" data-toggle="modal" data-target="#complaintModal{{$message->user_id}}"><i class="far fa-flag text-primary"></i> Report</a></div>
				</div>
			</div>
			@endforeach	
		</main>
	</div>
</div>

@foreach($senders as $item)
<div class="modal fade" id="complaintModal{{$item->user_id}}" tabindex="-1"  aria-hidden="true">
  <div class="modal-dialog dia-modal">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"> Report User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" action="{{route('report.user')}}" >
          @csrf	
						<input type="hidden" name="reported_id" value="{{$item->user_id}}" id="repo_id{{$item->user_id}}">									
						<p>Report inappropriate behavior and help other locals avoid unserious booking requests.</p>
            <div class="form-group">
              <!-- <label  class="col-form-label d-flex">Email:</label> -->
							<textarea name="report_message" class="form-control py-3 px-4" rows="3"   required="required"></textarea>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn buttons">Send Report</button>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>
@endforeach

@endsection